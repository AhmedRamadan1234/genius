<?php

// Image sizes
add_image_size('wavee_679x409', 679, 409, true); // Hero section featured image
add_image_size('wavee_285x220', 285, 220, true); // Portfolio Single Featured Image
add_image_size('wavee_480x370', 480, 370, true); // Portfolio Single Featured Image
add_image_size('wavee_24x29', 24, 29, true); // Service Single Thumbnails Image
add_image_size('wavee_960x484', 960, 484, true); // Masonry Portfolio


// Elementor is anchor external target
function wavee_is_external($settings_key) {
    if(isset($settings_key['is_external'])) {
        echo $settings_key['is_external'] == true ? 'target="_blank"' : '';
    }
}

// Elementor is anchor nofollow
function wavee_is_nofollow($settings_key) {
    if(isset($settings_key['nofollow'])) {
        echo $settings_key['nofollow'] == true ? 'rel="nofollow"' : '';
    }
}

// Limit latter
function wavee_limit_latter($string, $limit_length, $suffix = '...') {
    if (strlen($string) > $limit_length) {
        echo strip_shortcodes(substr($string, 0, $limit_length) . $suffix);
    }
    else {
        echo strip_shortcodes(esc_html($string));
    }
}

// Icon
function wavee_icon_array($k, $replace = 'icon', $separator = '-') {
    $v = array();
    foreach ($k as $kv) {
        $kv = str_replace($separator, ' ', $kv);
        $kv = str_replace($replace, '', $kv);
        $v[] = array_push($v, ucwords($kv));
    }
    foreach($v as $key => $value) if($key&1) unset($v[$key]);
    return array_combine($k, $v);
}



function cc_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');

// Single Blog Post Social Share
function wavee_social_share() {
    ?>
    <ul class="list-unstyled social_link social_link_two">
        <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="social_facebook"></i><i class="social_facebook"></i></a></li>
        <li><a href="https://www.twitter.com/intent/tweet?text=<?php the_permalink(); ?>"><i class="social_twitter"></i><i class="social_twitter"></i></a></li>
        <li><a href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink() ?>"><i class="social_pinterest"></i><i class="social_pinterest"></i></a></li>
        <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink() ?>"><i class="social_linkedin"></i><i class="social_linkedin"></i></a></li>
    </ul>
    <?php
}


// Portfolio post title
function wavee_get_portfolio_title() {
    $portfolio = array(
        'post_type' => 'portfolio',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
    );
    $portfolio_post = get_posts($portfolio);
    $portfolio_array = array();
    $portfolio_array[] = '';
    foreach ($portfolio_post as $p_id) {
        $portfolio_array[$p_id] = wp_trim_words( get_the_title( $p_id ), 5, '...');
    }
    return $portfolio_array;
}