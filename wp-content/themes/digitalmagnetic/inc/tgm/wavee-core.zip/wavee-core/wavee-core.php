<?php
/**
 * Plugin Name: Wavee Core
 * Plugin URI: https://themeforest.net/user/droitthemes/portfolio
 * Description: This plugin adds the core features to the Wavee WordPress theme. You must have to install this plugin to get all the features included with the theme.
 * Version: 1.0.8
 * Author: DroitThemes
 * Author URI: https://themeforest.net/user/droitthemes/portfolio
 * Text domain: wavee-core
 */

if ( !defined('ABSPATH') )
    die('-1');


// Make sure the same class is not loaded twice in free/premium versions.
if ( !class_exists( 'Wavee_core' ) ) {
	/**
	 * Main Wavee Core Class
	 *
	 * The main class that initiates and runs the Wavee Core plugin.
	 *
	 * @since 1.7.0
	 */
	final class Wavee_core {
		/**
		 * Wavee Core Version
		 *
		 * Holds the version of the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string The plugin version.
		 */
		const VERSION = '1.0' ;
		/**
		 * Minimum Elementor Version
		 *
		 * Holds the minimum Elementor version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum Elementor version required to run the plugin.
		 */
		const MINIMUM_ELEMENTOR_VERSION = '1.7.0';
		/**
		 * Minimum PHP Version
		 *
		 * Holds the minimum PHP version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum PHP version required to run the plugin.
		 */
		const  MINIMUM_PHP_VERSION = '5.4' ;
        /**
         * Plugin's directory paths
         * @since 1.0
         */
        const CSS = null;
        const JS = null;
        const IMG = null;
        const VEND = null;

		/**
		 * Instance
		 *
		 * Holds a single instance of the `Wavee_Core` class.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 * @static
		 *
		 * @var Wavee_Core A single instance of the class.
		 */
		private static  $_instance = null ;
		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 * @static
		 *
		 * @return Wavee_Core An instance of the class.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Clone
		 *
		 * Disable class cloning.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'wavee-core' ), '1.7.0' );
		}

		/**
		 * Wakeup
		 *
		 * Disable unserializing the class.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'wavee-core' ), '1.7.0' );
		}

		/**
		 * Constructor
		 *
		 * Initialize the Wavee Core plugins.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function __construct() {
			$this->core_includes();
			$this->init_hooks();
			do_action( 'wavee_core_loaded' );
		}

		/**
		 * Include Files
		 *
		 * Load core files required to run the plugin.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function core_includes() {
			// Extra functions
			require_once __DIR__ . '/inc/extra.php';

			// Custom post types
			require_once __DIR__ . '/post-type/portfolio.pt.php';
			require_once __DIR__ . '/post-type/service.pt.php';



            /**
             * Register widget area.
             *
             * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
             */
			require_once __DIR__ . '/wp-widgets/widgets.php';

			// Instagram Widget
            require_once __DIR__ . '/wp-widgets/instagram/instagram-api.php';
            require_once __DIR__ . '/wp-widgets/instagram/instagram-settings.php';
            require_once __DIR__ . '/wp-widgets/instagram/instagram-widget.php';

			// Elementor custom field icons
			require_once __DIR__ . '/fields/icons.php';

            // RGBA color picker
            require plugin_dir_path(__FILE__) . '/acf-rgba-color-picker/acf-rgba-color-picker.php';

            // ACF Metaboxes
            require plugin_dir_path(__FILE__) . '/inc/metaboxes.php';
		}

		/**
		 * Init Hooks
		 *
		 * Hook into actions and filters.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 */
		private function init_hooks() {
			add_action( 'init', [ $this, 'i18n' ] );
			add_action( 'plugins_loaded', [ $this, 'init' ] );
		}

		/**
		 * Load Textdomain
		 *
		 * Load plugin localization files.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function i18n() {
			load_plugin_textdomain( 'wavee-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
		}


		/**
		 * Init Wavee Core
		 *
		 * Load the plugin after Elementor (and other plugins) are loaded.
		 *
		 * @since 1.0.0
		 * @since 1.7.0 The logic moved from a standalone function to this class method.
		 *
		 * @access public
		 */
		public function init() {

			if ( !did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
				return;
			}

			// Check for required Elementor version

			if ( !version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
				return;
			}

			// Check for required PHP version

			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
				return;
			}

			// Add new Elementor Categories
			add_action( 'elementor/init', [ $this, 'add_elementor_category' ] );

			// Register Widget Scripts
			add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_widget_scripts' ] );
			add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_widget_scripts' ] );
            add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

			// Register Widget Scripts
			add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_widget_styles' ] );
			add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_widget_styles' ] );

			// Register New Widgets
			add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have Elementor installed or activated.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a standalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_missing_main_plugin() {
			$message = sprintf(
			/* translators: 1: Wavee Core 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'wavee-core' ),
				'<strong>' . esc_html__( 'Wavee core', 'wavee-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'wavee-core' ) . '</strong>'
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required Elementor version.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a standalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_minimum_elementor_version() {
			$message = sprintf(
			/* translators: 1: Wavee Core 2: Elementor 3: Required Elementor version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'wavee-core' ),
				'<strong>' . esc_html__( 'Wavee Core', 'wavee-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'wavee-core' ) . '</strong>',
				self::MINIMUM_ELEMENTOR_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required PHP version.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function admin_notice_minimum_php_version() {
			$message = sprintf(
			/* translators: 1: Wavee Core 2: PHP 3: Required PHP version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'wavee-core' ),
				'<strong>' . esc_html__( 'Wavee Core', 'wavee-core' ) . '</strong>',
				'<strong>' . esc_html__( 'PHP', 'wavee-core' ) . '</strong>',
				self::MINIMUM_PHP_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Add new Elementor Categories
		 *
		 * Register new widget categories for Wavee Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function add_elementor_category() {
			\Elementor\Plugin::instance()->elements_manager->add_category( 'wavee-elements', [
				'title' => __( 'Wavee Elements', 'wavee-core' ),
			], 1 );
		}

		/**
		 * Register Widget Scripts
		 *
		 * Register custom scripts required to run Wavee Core.
		 *
		 * @since 1.6.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */

		public function register_widget_scripts() {

            wp_register_script( 'ajax-chimp', plugins_url( 'assets/js/ajax-chimp.js', __FILE__ ), 'jquery', '1.0', true );
            wp_register_script( 'imagesloaded', plugins_url( 'assets/vendors/imagesloaded/imagesloaded.pkgd.min.js', __FILE__ ), 'jquery', '4.1.0', true );
            wp_register_script( 'isotope', plugins_url( 'assets/vendors/isotope/isotope-min.js', __FILE__ ), 'jquery', '3.0.1', true );

            // New Home Pages
            wp_register_script( 'splitting', plugins_url( 'assets/vendors/spiling/splitting.min.js', __FILE__ ), 'jquery', '1.0', true );
            wp_register_script( 'wavee-swiper', plugins_url( 'assets/vendors/swiper/swiper.min.js', __FILE__ ), 'jquery', '4.4.6', true );

            // Wavee Demo
            wp_register_script( 'owl-carousel', plugins_url( 'assets/demo/js/owl.carousel.min.js', __FILE__ ), 'jquery', '2.3.4', true );
            wp_register_script( 'parallax-min', plugins_url( 'assets/demo/js/parallax.min.js', __FILE__ ), 'jquery', '1.0', true );
            wp_register_script( 'parallax-scroll', plugins_url( 'assets/demo/js/parallax-scroll.js', __FILE__ ), 'jquery', '1.0', true );
            wp_register_script( 'scrollspy', plugins_url( 'assets/demo/js/scrollspy.js', __FILE__ ), 'jquery', '1.0', true );
            wp_enqueue_script( 'easing', plugins_url( 'assets/demo/js/easing.min.js', __FILE__ ), 'jquery', '1.0', true );
            wp_enqueue_script( 'mCustomScrollbar', plugins_url( 'assets/demo/js/mCustomScrollbar.js', __FILE__ ), 'jquery', '2.3.2 ', true );
            wp_register_script( 'waypoints', plugins_url( 'assets/demo/js/waypoints.min.js', __FILE__ ), 'jquery', '2.0.3', true );
            wp_register_script( 'counterup', plugins_url( 'assets/demo/js/counterup.min.js', __FILE__ ), 'jquery', '1.0', true );

            if ( defined( 'ELEMENTOR_VERSION') ) {
                if ( \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
                    wp_enqueue_script( 'owl-carousel' );
                    wp_enqueue_script( 'parallax-min' );
                    wp_enqueue_script( 'parallax-scroll' );
                    wp_enqueue_script( 'scrollspy' );
                    wp_enqueue_script( 'waypoints' );
                    wp_enqueue_script( 'counterup' );
                }
            }

		}

		/**
		 * Register Widget Styles
		 *
		 * Register custom styles required to run Wavee Core.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		
		public function enqueue_widget_styles() {

		    // New Home Pages
            wp_register_style( 'splitting', plugins_url( 'assets/vendors/spiling/splitting.css', __FILE__) );
            wp_register_style( 'swiper', plugins_url( 'assets/vendors/swiper/swiper.min.css', __FILE__) );

            //Wavee Demo
            wp_register_style( 'owl-theme', plugins_url( 'assets/demo/css/owl.theme.default.min.css', __FILE__) );
            wp_register_style( 'owl-carousel', plugins_url( 'assets/demo/css/owl.carousel.min.css', __FILE__) );
            wp_register_style( 'wavee-demo', plugins_url( 'assets/demo/css/wavee-demo.css', __FILE__) );

            if ( defined( 'ELEMENTOR_VERSION') ) {
                if ( \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
                    wp_enqueue_style( 'owl-carousel' );
                    wp_enqueue_style( 'owl-theme' );
                    wp_enqueue_style( 'wavee-demo' );

                }
            }
		}

        public function enqueue_scripts() {

        }

        /**
		 * Register New Widgets
		 *
		 * Include Wavee Core widgets files and register them in Elementor.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function on_widgets_registered() {
			$this->include_widgets();
			$this->register_widgets();
		}

		/**
		 * Include Widgets Files
		 *
		 * Load Wavee Core widgets files.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function include_widgets() {
			require_once __DIR__ . '/widgets/Wavee_hero.php';

			require_once __DIR__ . '/widgets/Wavee_c2a.php';

			require_once __DIR__ . '/widgets/Wavee_subscribe_form.php';

			require_once __DIR__ . '/widgets/Wavee_single_video.php';

			require_once __DIR__ . '/widgets/Wavee_features.php';

			require_once __DIR__ . '/widgets/Wavee_team.php';

			require_once __DIR__ . '/widgets/Wavee_testimonials.php';

			require_once __DIR__ . '/widgets/Wavee_clients_logo.php';

			require_once __DIR__ . '/widgets/Wavee_socials.php';

			require_once __DIR__ . '/widgets/Wavee_portfolio.php';

			require_once __DIR__ . '/widgets/Wavee_service.php';

			require_once __DIR__ . '/widgets/Wavee_contact_form.php';

			require_once __DIR__ . '/widgets/Wavee_full_screen_slider.php';

			require_once __DIR__ . '/widgets/Wavee_service_tabs.php';

			require_once __DIR__ . '/widgets/Wavee_Portfolio_masonry.php';

			//Wavee Demo
			require_once __DIR__ . '/widgets/two-column-features/Wavee_two_column_features.php';
			require_once __DIR__ . '/widgets/image-carousel/Wavee_image_carousel.php';

        }

		/**
		 * Register Widgets
		 *
		 * Register Wavee Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function register_widgets() {
			// Site Elements
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_hero() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_c2a() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_subscribe_form() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_single_video() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_features() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_team() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_testimonials() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_clients_logo() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_socials() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_portfolio() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_service() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_contact_form() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_full_screen_slider() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_service_tabs() );

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_Portfolio_masonry() );

			//Wavee Demo
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_two_column_features() );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WaveeCore\Widgets\Wavee_image_carousel() );

		}
	}
}
// Make sure the same function is not loaded twice in free/premium versions.

if ( !function_exists( 'wavee_core_load' ) ) {
	/**
	 * Load Wavee Core
	 *
	 * Main instance of Wavee_Core.
	 *
	 * @since 1.0.0
	 * @since 1.7.0 The logic moved from this function to a class method.
	 */
	function wavee_core_load() {
		return Wavee_core::instance();
	}

	// Run Wavee Core
    wavee_core_load();
}


function wavee_admin_cpt_script( ) {

}
add_action( 'admin_enqueue_scripts', 'wavee_admin_cpt_script', 10, 1 );